package com.meterware.kata.reversi;

/**
 * The possible disk colors in the game.
 */
public enum DiskColor {
    white, black, no_such_square
}
