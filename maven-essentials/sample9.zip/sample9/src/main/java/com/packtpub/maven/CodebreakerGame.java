package com.packtpub.maven;

import com.meterware.codebreaker.Codebreaker;
import com.meterware.codebreaker.Color;
import com.meterware.codebreaker.Result;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class CodebreakerGame {
    public static void main(String... args) throws IOException {
        Codebreaker guesser = new Codebreaker(5, false);
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        while (guesser.numCombinationsLeft() > 1) {
            Color[] guess = guesser.getNextGuess();
            System.out.print("My guess: " + Arrays.toString(guess) + " (enter result as num matches, num mismatches): ");
            String line = in.readLine();
            String[] strings = line.split(",");
            int numMatches = Integer.parseInt(strings[0].trim());
            int numMismatches = Integer.parseInt(strings[1].trim());
            guesser.addResult(guess, new Result(numMatches, numMismatches));
        }
        System.out.println("Final guess: " + Arrays.toString(guesser.getNextGuess()));
    }

}