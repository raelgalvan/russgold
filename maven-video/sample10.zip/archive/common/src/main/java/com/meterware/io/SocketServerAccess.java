package com.meterware.io;
/********************************************************************************************************************
 *
 * Copyright (c) 2004-2005, Russell Gold
 *
 *******************************************************************************************************************/

import java.io.*;
import java.net.Socket;

/**
 * Access to a server that uses socket I/O
 *
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class SocketServerAccess implements ServerAccess {

    private OutputStream outputStream;
    private InputStream inputStream;
    private boolean active;
    private Socket socket;
    private ClientMessageHandler handler;


    public static ServerAccess connectToRemoteServer(String host, int port) throws IOException {
        return new SocketServerAccess(new Socket(host, port));
    }


    private SocketServerAccess(Socket socket) throws IOException {
        this.socket = socket;
        outputStream = new BufferedOutputStream(socket.getOutputStream());
        inputStream = new BufferedInputStream(socket.getInputStream());
    }


    public InputStream getInputStream() {
        return inputStream;
    }


    public OutputStream getOutputStream() {
        return outputStream;
    }


    @Override
    public void disconnect() throws IOException {
        active = false;
        outputStream.close();
        socket.close();
    }


    @Override
    public void pause() {
        active = false;
    }


    @Override
    public void resume() {
        active = true;
        Thread thread = new Thread(new MessageHandler());
        thread.setDaemon(true);
        thread.start();
    }

    private ClientMessageHandler getHandler() {
        return handler;
    }

    @Override
    public void setHandler(ClientMessageHandler handler) {
        this.handler = handler;
    }

    /**
     * Extracts length-delineated messages from the specified byte array and invokes the handler for each one.
     *
     * @param bytes bytes received
     */
    protected void handleMessages(byte[] bytes) {
        MessageIterator mi = new MessageIterator(bytes);
        while (mi.hasNext()) {
            getHandler().handleMessage(mi.next());
        }
    }

    @Override
    public void sendRequest(byte[] requestBody) throws IOException {
        getOutputStream().write(requestBody);
        getOutputStream().flush();
    }


    private class MessageHandler implements Runnable {

        public void run() {
            while (active) {
                try {
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                    }
                    ;
                    int available = getInputStream().available();
                    if (available == 0) continue;
                    byte[] bytes = new byte[available];
                    getInputStream().read(bytes);
                    SocketServerAccess.this.handleMessages(bytes);
                } catch (IOException e) {
                    if (active) e.printStackTrace();  //To change body of catch statement use Options | File Templates.
                }
            }
        }
    }

}
