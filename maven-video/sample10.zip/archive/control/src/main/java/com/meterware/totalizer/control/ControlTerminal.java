package com.meterware.totalizer.control;
/********************************************************************************************************************
 * $Id$
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/

import com.meterware.io.ClientMessageHandler;
import com.meterware.io.ServerAccess;
import com.meterware.totalizer.Card;
import com.meterware.totalizer.Race;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class ControlTerminal implements ControlViewListener {

    private ControlView view;
    private ServerAccess serverAccess;

    private Card card;
    private int[] openRaces;
    private int raceNum;
    private int winHorseNum;
    private int placeHorseNum;
    private int showHorseNum;


    public ControlTerminal(ServerAccess serverAccess, ControlView view) {
        this.view = view;
        view.setListener(this);
        this.serverAccess = serverAccess;
        this.serverAccess.resume();
        this.serverAccess.setHandler(new TerminalMessageHandler());
    }


    @Override
    public void selectWinner(int horseNum) {
        winHorseNum = horseNum;
        Race race = card.getRace(raceNum);
        ArrayList<String> horses = new ArrayList<String>();
        for (int i = 0; i < race.getNumHorses(); i++) {
            if (winHorseNum == i + 1) continue;
            horses.add((i + 1) + " " + race.getHorse(i + 1).getName());
        }
        this.view.setPossiblePlacers(horses.toArray(new String[horses.size()]));
    }


    @Override
    public void selectPlace(int horseNum) {
        placeHorseNum = horseNum;
        Race race = card.getRace(raceNum);
        ArrayList<String> horses = new ArrayList<String>();
        for (int i = 0; i < race.getNumHorses(); i++) {
            if (winHorseNum == i + 1) continue;
            if (placeHorseNum == i + 1) continue;
            horses.add((i + 1) + " " + race.getHorse(i + 1).getName());
        }
        view.setPossibleShowers(horses.toArray(new String[horses.size()]));
    }


    @Override
    public void selectShow(int horseNum) {
        showHorseNum = horseNum;
    }


    @Override
    public void selectRace(int raceNum) {
        this.raceNum = raceNum;
        Race race = card.getRace(raceNum);
        ArrayList<String> horses = new ArrayList<String>();
        for (int i = 0; i < race.getNumHorses(); i++) {
            horses.add((i + 1) + " " + race.getHorse(i + 1).getName());
        }
        view.setPossibleWinners(horses.toArray(new String[horses.size()]));
    }


    @Override
    public void displayResults() {
        sendRequest("RESULTS " + card.getTrack() + " " + raceNum + " " + winHorseNum + " " + placeHorseNum + " " + showHorseNum);
        updateOfferedRaces();
    }

    private void sendRequest(String request) {
        try {
            serverAccess.sendRequest(request.getBytes("UTF8"));
        } catch (IOException e) {
            reportException(e);
        }
    }

    private void updateOfferedRaces() {
        for (int i = 0; i < openRaces.length; i++) {
            int openRace = openRaces[i];
            if (openRace == raceNum) {
                int[] races = new int[openRaces.length - 1];
                System.arraycopy(openRaces, 0, races, 0, i);
                System.arraycopy(openRaces, i + 1, races, i, races.length - i);
                openRaces = races;
                this.view.setOfferedRaces(openRaces);
                break;
            }
        }
    }

    private void reportException(Exception e) {
        e.printStackTrace();
    }

    @Override
    public void displayOdds() {
        sendRequest("DISPLAY " + card.getTrack() + ' ' + raceNum);
    }

    @Override
    public void loadCard(File file) {
        sendRequest(("LOAD " + file.getAbsolutePath()));
    }

    private void setCard(Card card) {
        this.card = card;
        view.setTrackName(card.getTrack());
        openRaces = new int[card.getNumRaces()];
        for (int i = 0; i < openRaces.length; i++) {
            openRaces[i] = (i + 1);
        }
        view.setOfferedRaces(openRaces);
    }


    class TerminalMessageHandler implements ClientMessageHandler {

        public boolean handleMessage(byte[] bytes) {
            try {
                ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                ObjectInputStream ois = new ObjectInputStream(bais);
                Object result = ois.readObject();
                if (result instanceof Card) {
                    setCard((Card) result);
                } else {
                    reportException(new RuntimeException("Received " + result + " instead of a Card"));
                }
            } catch (IOException e) {
                reportException(e);
            } catch (ClassNotFoundException e) {
                reportException(e);
            }
            return true;
        }
    }

}
