package com.meterware.totalizer.display.gui;
/********************************************************************************************************************
 * $Id$
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/

import com.meterware.totalizer.display.Layoutable;
import com.meterware.totalizer.display.ToteBoardFormat;
import com.meterware.totalizer.display.ToteBoardLayout;

import javax.swing.*;
import java.awt.*;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class ToteBoardView implements Layoutable {

    private ToteBoardLayout layout;
    private JPanel panel;
    private Font font;
    private Font titleFont;


    public void setFont(Font font) {
        this.font = font;
    }


    public void setTitleFont(Font font) {
        titleFont = font;
    }


    @Override
    public int getTitleWidth(String title) {
        return getTitleFontMetrics().stringWidth(title);
    }


    private FontMetrics getTitleFontMetrics() {
        return panel.getFontMetrics(titleFont);
    }


    @Override
    public int getPanelWidth() {
        return panel.getWidth();
    }

    @Override
    public int getTitleHeight() {
        return getTitleFontMetrics().getHeight();
    }

    @Override
    public int getDisplayHeight() {
        return panel.getFontMetrics(font).getHeight();
    }

    @Override
    public int getDisplayWidth(String string) {
        return panel.getFontMetrics(font).stringWidth(string);
    }


    void draw(Graphics g) {
        g.setFont(titleFont);
        Point p = layout.getTitlePosition();
        g.drawString(layout.getTitle(), (int) p.getX(), (int) p.getY());

        g.setFont(font);
        for (int i = 1; i < layout.numRows(); i++) {
            for (int j = 0; j < layout.numColumns(i); j++) {
                if (layout.getData(i, j) != null) {
                    Point p2 = layout.getItemPosition(i, j);
                    g.drawString(layout.getData(i, j), (int) p2.getX(), (int) p2.getY());
                }
            }
        }
    }


    public ToteBoardView(JPanel panel, ToteBoardFormat format) {
        this.panel = panel;
        layout = new ToteBoardLayout(format, this);
    }


    void setValue(int i, int j, String value) {
        layout.setValue( i, j, value );
    }
}
