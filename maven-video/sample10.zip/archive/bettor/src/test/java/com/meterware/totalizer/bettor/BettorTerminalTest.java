package com.meterware.totalizer.bettor;

import com.meterware.io.ClientMessageHandler;
import com.meterware.io.ServerAccess;
import com.meterware.totalizer.Card;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class BettorTerminalTest {

    private TestBettorView view = new TestBettorView();
    private final TestServerAccess server = new TestServerAccess();
    private Card card = new Card();

    private BettorTerminal terminal = new BettorTerminal("Track1", view, server);

    @Before
    public void setUp() throws IOException {
        card.setTrack("Track1");
        card.createRace().addHorse(1, 2.0).addHorse(2, 3.0).addHorse(3, 0.5);
        card.createRace().addHorse(4, 1.5).addHorse(5, .75).addHorse(6, 4.0);
        card.createRace().addHorse(7, 5.0).addHorse(8, 1.0).addHorse(9, 2.5);
        server.replyWith(card);
    }

    @Test
    public void whenTerminalStarted_ResumesAccess() {
        assertTrue(server.active);
    }

    @Test
    public void whenTerminalStarted_DownloadsCard() {
        assertIsCardDownLoadFor("Track1", server.commands.get(0));
    }

    private void assertIsCardDownLoadFor(String track1, byte[] bytes) {
        assertCommandEquals("DOWNLOAD " + track1, bytes);
    }

    private void assertCommandEquals(String commandString, byte[] bytes) {
        assertEquals(commandString, new String(bytes));
    }

    @Test
    public void whenTerminalStartedDisplaysTrackName() throws IOException {
        assertEquals("Track1", view.trackName);
    }

    @Test
    public void whenTerminalStartedOffersRaces() throws IOException {
        assertArrayEquals(new int[]{1, 2, 3}, view.openRaces);
    }

    @Test
    public void whenTerminalStarted_firstRaceIsSelected() {
        assertArrayEquals(new String[]{"1 Horse1", "2 Horse2", "3 Horse3"},
                view.horseStrings);
    }

    @Test
    public void whenTerminalStarted_offerWinPlaceAndShow() {
        assertArrayEquals(new String[] {"Win", "Place", "Show"}, view.pools);
    }

    @Test
    public void whenSecondRaceSelected_displayHorseNames() {
        view.selectRace(2);
        assertArrayEquals(new String[]{"1 Horse4", "2 Horse5", "3 Horse6"}, view.horseStrings);
    }

    @Test
    public void whenUsePlacesBet_sendToServer() {
        server.commands.clear();
        view.placeBet(2, "PLACE", 30);
        assertBetPlaced(server.commands.get(0), 2, "PLACE-1", 30);
    }

    private void assertBetPlaced(byte[] command, int horse, String poolName, double amount) {
        assertCommandEquals("BET Track1 " + poolName + ' ' + horse + ' ' + amount, command);
    }

    private static class TestBettorView implements BettorView {

        private String trackName;
        private int[] openRaces = new int[0];
        private BettorListener listener;
        private String[] horseStrings;
        private String[] pools;

        private void selectRace(int num) {
            listener.selectRace(num);
        }

        private void placeBet(int horse, String poolName, int amount) {
            listener.submitBet(horse, poolName, amount);
        }

        public void setListener(BettorListener listener) {
            this.listener = listener;
        }

        public void setTrackName(String trackName) {
            this.trackName = trackName;
        }

        public void setOfferedRaces(int[] openRaces) {
            this.openRaces = openRaces;
        }

        public void setOfferedHorses(String[] horseStrings) {
            this.horseStrings = horseStrings;
        }

        public void setOfferedPools(String[] pools) {
            this.pools = pools;
        }


    }
    private static class TestServerAccess implements ServerAccess {
        private boolean active;
        private List<byte[]> commands = new ArrayList<byte[]>();
        private ClientMessageHandler handler;

        void replyWith(Serializable download) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(download);
            handler.handleMessage(baos.toByteArray());
        }

        public void disconnect() {}
        public void pause() {}

        public void resume() {
            active = true;
        }

        @Override
        public void setHandler(ClientMessageHandler handler) {
            this.handler = handler;
        }

        @Override
        public void sendRequest(byte[] requestBody) throws IOException {
            commands.add(requestBody);
        }

    }
}
