package com.meterware.totalizer.bettor;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public interface BettorListener {

    void selectRace(int raceNum);

    void submitBet(int horseNum, String poolName, double betAmount);
}
