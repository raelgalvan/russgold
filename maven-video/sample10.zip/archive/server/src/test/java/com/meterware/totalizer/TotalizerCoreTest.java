package com.meterware.totalizer;
/********************************************************************************************************************
 *
 * Copyright (c) 2008, Russell Gold
 *
 *******************************************************************************************************************/

import com.meterware.io.MessageIterator;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class TotalizerCoreTest {

    private List<String> toteBoardCommands = new ArrayList<String>();
    private TotalizerCore totalizer;
    private List<Object> replies = new ArrayList<Object>();
    private TestStopWatch stopWatch = new TestStopWatch();

    @Before
    public void setUp() throws IOException {
        Track.clear();
        totalizer = new TotalizerCore(stopWatch,
                                      new ToteBoardAccess() {
            @Override
            public void newFrame(int format) throws IOException {
                toteBoardCommands.add( String.format( "NEW %d", format ) );
            }

            @Override
            public void sendData(int row, int column, Object value) throws IOException {
                toteBoardCommands.add( String.format( "DATA %d %d %s", row, column, value ) );
            }

            @Override
            public void endFrame() throws IOException {
                toteBoardCommands.add( "END" );
            }
        });
    }


    private Card createCard() {
        Card card = new Card();
        card.setTrack( "Belmont" );
        card.setDate(new Date());
        createRace( card, "Lucky Dan", "2:1", "Charlie Horse", "10:1", "Red Flag", "3:2", "Holy Roller", "4:3" );
        return card;
    }


    @Test
    public void whenTerminalRequestsOdds_toteBoardUpdated() throws Exception {
        totalizer.setCard(createCard());

        sendRequest("DISPLAY Belmont 1");

        assertCommands("NEW 0",
                "DATA 0 0 Belmont", "DATA 0 1 1",
                "DATA 1 0 1", "DATA 1 1 Lucky Dan",     "DATA 1 2 2-1",
                "DATA 2 0 2", "DATA 2 1 Charlie Horse", "DATA 2 2 10-1",
                "DATA 3 0 3", "DATA 3 1 Red Flag",      "DATA 3 2 3-2",
                "DATA 4 0 4", "DATA 4 1 Holy Roller",   "DATA 4 2 4-3",
                "END");
    }
    
    
    @Test
    public void afterTwoBets_oddsAreNotUpdated() throws IOException {
        totalizer.setCard(createCard());
        sendRequest("DISPLAY Belmont 1");
        toteBoardCommands.clear();
        
        sendRequest( "BET Belmont WIN-1 1 30.00" );
        sendRequest( "BET Belmont WIN-1 2 12.00" );
        assertTrue(toteBoardCommands.isEmpty());
    }


    @Test
    public void afterThreeBetsAnd19Seconds_oddsAreNotUpdated() throws IOException, InterruptedException {
        totalizer.setCard(createCard());
        sendRequest("DISPLAY Belmont 1");
        toteBoardCommands.clear();

        sendRequest( "BET Belmont WIN-1 1 30.00" );
        sendRequest( "BET Belmont WIN-1 2 12.00" );
        stopWatch.setElapsedTime( 19 );
        sendRequest("BET Belmont WIN-1 3 40.00");
        assertTrue(toteBoardCommands.isEmpty());
    }

    @Test
    public void afterThreeBetsAnd21Seconds_oddsAreUpdated() throws IOException, InterruptedException {
        totalizer.setCard(createCard());
        sendRequest("DISPLAY Belmont 1");
        toteBoardCommands.clear();

        sendRequest( "BET Belmont WIN-1 1 30.00" );
        sendRequest( "BET Belmont WIN-1 2 12.00" );
        stopWatch.setElapsedTime( 21 );
        sendRequest("BET Belmont WIN-1 3 40.00");
        assertFalse(toteBoardCommands.isEmpty());
    }

    private void createRace(Card card, String... data) {
        Race race = card.createRace();
        int i = 0;
        while (i < data.length) {
            Race.Horse horse = race.createHorse();
            horse.setName( data[i++] );
            horse.setOdds( data[i++] );
        }
    }


    private void assertCommands( String... expected ) {
        assertEquals( expected.length, toteBoardCommands.size() );
        for (int i = 0; i < expected.length; i++) {
            assertEquals( expected[i], withoutNBSP(toteBoardCommands.get(i)));
        }
    }

    String withoutNBSP(String s) {
        return s.replace((char) 0x0a0, ' ');
    }

    private void sendRequest( String request ) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        totalizer.handleRequest(request.getBytes(), baos);

        byte[] bytes = baos.toByteArray();
        handleMessages(bytes);
    }

    protected void handleMessages( byte[] bytes ) {
        Iterator mi = new MessageIterator( bytes );
        while (mi.hasNext()) {
            byte[] message = (byte[]) mi.next();
            try {
                ByteArrayInputStream bais = new ByteArrayInputStream( message );
                ObjectInputStream ois = new ObjectInputStream( bais );
                Object result = ois.readObject();
                replies.add( result );
            } catch (Exception e) {
                replies.add(e);
            }
        }
    }
    
    
    class TestStopWatch implements StopWatch {
        
        private int elapsedTime;

        void setElapsedTime( int elapsedTime ) {
            this.elapsedTime = elapsedTime;
        }

        @Override
        public void resetTimer() {
            elapsedTime = 0;
        }

        @Override
        public long getElapsedTime() {
            return elapsedTime;
        }
    }


}
