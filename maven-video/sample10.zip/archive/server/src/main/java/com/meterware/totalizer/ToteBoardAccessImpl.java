package com.meterware.totalizer;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

class ToteBoardAccessImpl implements ToteBoardAccess {
    OutputStreamWriter _writer;

    ToteBoardAccessImpl(int port) throws IOException {
        Socket socket = new Socket("localhost", port);
        OutputStream outputStream = socket.getOutputStream();
        _writer = new OutputStreamWriter(outputStream, "UTF-8");
    }

    @Override
    public void newFrame(int format) throws IOException {
        sendMessage("NEW " + format);
    }

    @Override
    public void sendData(int row, int column, Object value) throws IOException {
        sendMessage("DATA " + row + ' ' + column + ' ' + value);
    }

    @Override
    public void endFrame() throws IOException {
        sendMessage("END");
    }

    private void sendMessage(String message) throws IOException {
        _writer.write(message.length() + ">");
        _writer.write(message);
        _writer.flush();
    }

}