package com.meterware.totalizer.display;

public abstract class JustifiedColumn {
    private int maxWidth;

    public static JustifiedColumn createLeftJustifiedColumn() {
        return new LeftJustifiedColumn();
    }

    public static JustifiedColumn createRightJustifiedColumn() {
        return new RightJustifiedColumn();
    }

    public static JustifiedColumn createSeparatorJustifiedColumn(char separator) {
        return new SeparatorJustifiedColumn(separator);
    }

    public void addValue(DisplayMetrics metrics, String s) {
        maxWidth = Math.max(maxWidth, metrics.getDisplayWidth(s));
    }

    public abstract int getOffset(String s, DisplayMetrics metrics);

    public int getMaxWidth() {
        return maxWidth;
    }

    private JustifiedColumn() {
    }


    private static class LeftJustifiedColumn extends JustifiedColumn {
        private LeftJustifiedColumn() {
        }

        public int getOffset(String s, DisplayMetrics metrics) {
            return 0;
        }
    }


    private static class RightJustifiedColumn extends JustifiedColumn {
        private RightJustifiedColumn() {
        }

        public int getOffset(String s, DisplayMetrics metrics) {
            return getMaxWidth() - metrics.getDisplayWidth(s);
        }
    }


    private static class SeparatorJustifiedColumn extends JustifiedColumn {

        private int maxLeft;
        private int maxRight;
        private char separator;

        private SeparatorJustifiedColumn(char separator) {
            this.separator = separator;
        }

        public void addValue(DisplayMetrics metrics, String s) {
            maxLeft = Math.max(maxLeft, getLeft(metrics, s));
            maxRight = Math.max(maxRight, getRight(metrics, s));
        }

        public int getOffset(String s, DisplayMetrics metrics) {
            return maxLeft - getLeft(metrics, s);
        }

        public int getMaxWidth() {
            return maxLeft + maxRight;
        }

        private int getLeft(DisplayMetrics metrics, String s) {
            return metrics.getDisplayWidth(containsSeperator(s) ? s.substring(0, s.indexOf(separator)) : s);
        }

        private int getRight(DisplayMetrics metrics, String s) {
            return metrics.getDisplayWidth(containsSeperator(s) ? s.substring(s.indexOf(separator)) : "");
        }

        private boolean containsSeperator(String s) {
            return s.indexOf(separator) >= 0;
        }
    }
}
