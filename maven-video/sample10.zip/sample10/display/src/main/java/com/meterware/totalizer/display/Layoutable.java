package com.meterware.totalizer.display;

/**
 * Created with IntelliJ IDEA.
 * User: russgold
 * Date: 4/28/13
 * Time: 3:55 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Layoutable extends DisplayMetrics {
    int getDisplayHeight();

    int getTitleHeight();

    int getPanelWidth();

    int getTitleWidth(String title);
}
