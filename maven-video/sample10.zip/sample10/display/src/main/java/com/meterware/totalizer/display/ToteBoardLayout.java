package com.meterware.totalizer.display;

import java.awt.Point;

public class ToteBoardLayout {
    private ToteBoardFormat format;
    private Layoutable layoutable;
    private String[][] data = new String[1][];
    private Point[][] positions;

    public ToteBoardLayout(ToteBoardFormat format, Layoutable layoutable) {
        this.format = format;
        this.layoutable = layoutable;
    }

    public void setValue(int row, int column, String value) {
        if (value == null) return;

        positions = null;
        if (data.length <= row)
            growData(row + 1);

        if (data[row] == null)
            data[row] = new String[column + 1];
        else if (data[row].length <= column)
            growRow(row, column + 1);

        data[row][column] = value;
    }

    private void growData(int rowsNeeded) {
        String[][] newData = new String[rowsNeeded][];
        System.arraycopy(data, 0, newData, 0, data.length);
        data = newData;
    }

    private void growRow(int row, int columnsNeeded) {
        String[] newRow = new String[columnsNeeded];
        System.arraycopy(data[row], 0, newRow, 0, data[row].length);
        data[row] = newRow;
    }

    public String getTitle() {
        return format.getTitleIntro() + " for Race " + data[0][1] + " at " + data[0][0];
    }

    public Point getTitlePosition() {
        String title = getTitle();
        return new Point((layoutable.getPanelWidth() - layoutable.getTitleWidth(title)) / 2,
                         2 * layoutable.getTitleHeight());
    }

    public Point getItemPosition(int row, int column) {
        if (positions == null) {
            JustifiedColumn[] columnFormats = format.getColumnFormats();
            for (int i = 1; i < data.length; i++) {
                for (int j = 0; j < data[i].length; j++) {
                    String string = data[i][j];
                    if (string == null) continue;
                    columnFormats[j].addValue(layoutable, data[i][j]);
                }
            }
            int totalWidth = getTotalDisplayWidth(columnFormats);
            int[] colX = getColumnXPositions(columnFormats, totalWidth);
            int[] rowY = getRowYPositions();

            positions = new Point[data.length][];
            for (int i = 1; i < data.length; i++) {
                positions[i] = new Point[data[i].length];
                for (int j = 0; j < data[i].length; j++) {
                    if (data[i][j] == null) continue;
                    positions[i][j] = new Point(colX[j] + columnFormats[j].getOffset(data[i][j], layoutable),
                                                rowY[i]);
                }
            }
        }
        return positions[row][column];
    }

    private int getTotalDisplayWidth(JustifiedColumn[] columns) {
        int total = 0;
        for (JustifiedColumn column : columns)
            total += column.getMaxWidth() + layoutable.getDisplayWidth("M");
        return total -  layoutable.getDisplayWidth("M");
    }

    /**
     * Computes the positions of the data rows by spacing them apart by the panel display height. The topmost row
     * is places 3 title line heights below the title.
     */
    private int[] getRowYPositions() {
        int rowY[] = new int[data.length];
        rowY[1] = 3 * layoutable.getTitleHeight() + layoutable.getDisplayHeight();
        for (int i = 2; i < rowY.length; i++) {
            rowY[i] = rowY[i - 1] + layoutable.getDisplayHeight();
        }
        return rowY;
    }


    /**
     * Uses the total columns width to center the columns in the panel.
     *
     * @param columns the column format information
     * @param totalWidth the total width of the data, including spacing
     * @return an array of start positions for the columns
     */
    private int[] getColumnXPositions(JustifiedColumn[] columns, int totalWidth) {
        int[] colX = new int[columns.length];
        int panelWidth = layoutable.getPanelWidth();
        colX[0] = (panelWidth - totalWidth) / 2;
        for (int i = 1; i < columns.length; i++)
            colX[i] = colX[i-1] + columns[i-1].getMaxWidth()  + layoutable.getDisplayWidth("M");
        return colX;
    }

    public int numRows() {
        return data.length;
    }

    public int numColumns(int row) {
        return data[row].length;
    }

    public String getData(int row, int column) {
        return data[row][column];
    }
}
