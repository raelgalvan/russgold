package com.meterware.totalizer.display;

public enum ToteBoardFormat {
    odds {
        String getTitleIntro() {
            return "Odds";
        }

        JustifiedColumn[] getColumnFormats() {
            return new JustifiedColumn[] {
                    JustifiedColumn.createLeftJustifiedColumn(),           // horse num
                    JustifiedColumn.createLeftJustifiedColumn(),           // horse name
                    JustifiedColumn.createSeparatorJustifiedColumn('-'),   // odds
            };
        }
    },

    results {
        String getTitleIntro() {
            return "Results";
        }

        @Override
        JustifiedColumn[] getColumnFormats() {
            return new JustifiedColumn[] {
                    JustifiedColumn.createLeftJustifiedColumn(),           // horse num
                    JustifiedColumn.createLeftJustifiedColumn(),           // horse name
                    JustifiedColumn.createRightJustifiedColumn(),          // win payout
                    JustifiedColumn.createRightJustifiedColumn(),          // place payout
                    JustifiedColumn.createRightJustifiedColumn()           // show payout
            };
        }
    };

    abstract String getTitleIntro();

    abstract JustifiedColumn[] getColumnFormats();

    static public ToteBoardFormat getFormat(int selector) {
        return selector == Constants.FMT_ODDS ? odds : results;
    }
}
