package com.meterware.totalizer.display.gui;
/********************************************************************************************************************
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/
import com.meterware.totalizer.display.ToteBoardFormat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class ToteBoard implements Runnable {

    private JPanel _display;
    private ToteBoardView _currentView;
    private ToteBoardView _newView;
    private ServerSocket _serverSocket;


    public static void main(String... args) {
        try {
            Frame frame = new Frame();
            frame.addWindowListener(
                    new WindowAdapter() {
                        public void windowClosing(WindowEvent e) {
                            System.exit(0);
                        }
                    }
            );
            frame.setLayout(new GridLayout());
            ToteBoard toteBoard = new ToteBoard(5002);
            frame.add(toteBoard.getPanel());
            frame.setSize(500, 300);
            frame.setVisible(true);
            new Thread(toteBoard).start();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }


    public ToteBoard(int port) throws IOException {
        _serverSocket = new ServerSocket(port);
        _display = new JPanel() {
            public void paint(Graphics g) {
                if (_currentView == null) {
                    super.paint(g);
                } else {
                    g.setColor(getBackground());
                    g.fillRect(0, 0, getWidth(), getHeight());
                    g.setColor(getForeground());
                    _currentView.draw(g);
                }
            }
        };
    }


    private JPanel getPanel() {
        return _display;
    }


    protected void handleRequest(byte[] bytes) throws UnsupportedEncodingException {
        String request = new String(bytes, "UTF-8");
        while (request.length() > 0) {
            int i = request.indexOf('>');
            assert i > 0 : "no length indicator sent";
            String lengthString = request.substring(0, i);
            int length = Integer.parseInt(lengthString);
            handleRequest(request.substring(i + 1, i + length + 1));
            request = request.substring(i + length + 1);
        }
    }


    private void handleRequest(String request) {
        StringTokenizer st = new StringTokenizer(request);
        String command = st.nextToken();
        if (command.equalsIgnoreCase("new")) {
            startNewFrame(_display, Integer.parseInt(st.nextToken()));
        } else if (command.equalsIgnoreCase("data")) {
            int row = Integer.parseInt(st.nextToken());
            int column = Integer.parseInt(st.nextToken());
            String value = withoutNBSP(st.nextToken());
            this.setData(row, column, value);
        } else if (command.equalsIgnoreCase("end")) {
            displayNewFrame(_display);
        }
    }


    private String withoutNBSP(String s) {
        return s.replace((char) 0x0a0, ' ');
    }


    void startNewFrame(JPanel panel, int format) {
        _newView = new ToteBoardView(panel, ToteBoardFormat.getFormat(format));
    }


    void setData(int i, int j, String value) {
        _newView.setValue(i, j, value);
    }


    void displayNewFrame(JPanel panel) {
        _currentView = _newView;
        _newView = null;
        _currentView.setFont(new Font("Monospaced", Font.PLAIN, 18));
        _currentView.setTitleFont(new Font("Monospaced", Font.PLAIN, 24));
        panel.repaint();
    }


    public void run() {
        try {
            Socket socket = _serverSocket.accept();
            InputStream inputStream = socket.getInputStream();
            byte[] buffer = new byte[2048];
            int size;
            while (-1 < (size = inputStream.read(buffer))) {
                byte[] request = new byte[size];
                System.arraycopy(buffer, 0, request, 0, size);
                handleRequest(request);
            }
            socket.close();
            _serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
