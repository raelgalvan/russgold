package com.meterware.totalizer.display;

public interface DisplayMetrics {

    int getDisplayWidth(String s);

}
