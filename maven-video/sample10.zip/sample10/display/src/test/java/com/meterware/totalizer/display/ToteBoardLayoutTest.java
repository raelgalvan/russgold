package com.meterware.totalizer.display;

import org.junit.Test;

import java.awt.*;

import static org.junit.Assert.assertEquals;

public class ToteBoardLayoutTest {

    @Test
    public void oddsLayout() {
        ToteBoardLayout layout = new ToteBoardLayout(ToteBoardFormat.odds, new TestLayoutable());
        layout.setValue(1, 0, "1" );
        layout.setValue(1, 1, "Horse");
        layout.setValue(1, 2, "20-1");

        layout.setValue(2, 0, "2" );        // max width  5
        layout.setValue(2, 1, "Charlene");  // max width 40
        layout.setValue(2, 2, "1-15");      // max width 25, total 80 - borders 60 each

        assertEquals(new Point(60, 70), layout.getItemPosition(1, 0));
        assertEquals(new Point(70, 70), layout.getItemPosition(1, 1));
        assertEquals(new Point(115, 70), layout.getItemPosition(1, 2));
        assertEquals(new Point(60, 80), layout.getItemPosition(2, 0));
        assertEquals(new Point(70, 80), layout.getItemPosition(2, 1));
        assertEquals(new Point(120, 80), layout.getItemPosition(2, 2));
    }

    @Test
    public void resultsLayout() {
        ToteBoardLayout layout = new ToteBoardLayout(ToteBoardFormat.results, new TestLayoutable());
        layout.setValue(1, 0, "1" );       // max width  5
        layout.setValue(1, 1, "Horse");    // max width 35
        layout.setValue(1, 2, "12.60");    // max width 25
        layout.setValue(1, 3, "11.05");    // max width 25
        layout.setValue(1, 4, "2.20");     // max width 20, total 130, borders 35 each

        layout.setValue(2, 0, "2" );
        layout.setValue(2, 1, "Charlie");
        layout.setValue(2, 3, "2.70");
        layout.setValue(1, 4, "2.25");

        layout.setValue(3, 0, "1" );
        layout.setValue(3, 1, "Old Joe");
        layout.setValue(3, 4, "2.25");

        assertEquals(new Point( 35, 70), layout.getItemPosition(1, 0));
        assertEquals(new Point( 45, 70), layout.getItemPosition(1, 1));
        assertEquals(new Point( 85, 70), layout.getItemPosition(1, 2));
        assertEquals(new Point(115, 70), layout.getItemPosition(1, 3));
        assertEquals(new Point(145, 70), layout.getItemPosition(1, 4));

        assertEquals(new Point(120, 80), layout.getItemPosition(2, 3));
    }

    private class TestLayoutable implements Layoutable {
        public int getDisplayHeight() { return 10; }
        public int getTitleHeight() { return 20; }
        public int getPanelWidth() { return 200; }
        public int getTitleWidth(String title) { return 8 * title.length(); }
        public int getDisplayWidth(String s) { return 5 * s.length(); }
    }
}
