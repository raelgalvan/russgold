package com.meterware.totalizer.display;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class JustifiedColumnTest {

    private static final TestDisplayMetrics DISPLAY_METRICS = new TestDisplayMetrics();

    @Test
    public void leftJustifiedColumn_alwaysReturnsStartPosition() {
        JustifiedColumn column = JustifiedColumn.createLeftJustifiedColumn();
        column.addValue(DISPLAY_METRICS, "123");
        column.addValue(DISPLAY_METRICS, "abcedef");
        column.addValue(DISPLAY_METRICS, "12.34");

        assertEquals(35, column.getMaxWidth());

        assertEquals(0, column.getOffset("123", DISPLAY_METRICS));
        assertEquals(0, column.getOffset("abcdef", DISPLAY_METRICS));
        assertEquals(0, column.getOffset("12.34", DISPLAY_METRICS));
    }

    @Test
    public void rightJustifiedColumn_adjustsForContents() {
        JustifiedColumn column = JustifiedColumn.createRightJustifiedColumn();
        column.addValue(DISPLAY_METRICS, "123");
        column.addValue(DISPLAY_METRICS, "abcedef");
        column.addValue(DISPLAY_METRICS, "12.34");

        assertEquals(35, column.getMaxWidth());

        assertEquals(20, column.getOffset("123", DISPLAY_METRICS));
        assertEquals(5, column.getOffset("abcdef", DISPLAY_METRICS));
        assertEquals(10, column.getOffset("12.34", DISPLAY_METRICS));
    }

    @Test
    public void separatorJustifiedColumn_linesUpSeperators() {
        JustifiedColumn column = JustifiedColumn.createSeparatorJustifiedColumn('-');
        column.addValue(DISPLAY_METRICS, "103");
        column.addValue(DISPLAY_METRICS, "3-23");
        column.addValue(DISPLAY_METRICS, "23-1");

        assertEquals(30, column.getMaxWidth());

        assertEquals(0, column.getOffset("103", DISPLAY_METRICS));
        assertEquals(10, column.getOffset("3-23", DISPLAY_METRICS));
        assertEquals(5, column.getOffset("23-1", DISPLAY_METRICS));
    }

    static class TestDisplayMetrics implements DisplayMetrics {
        public int getDisplayWidth(String s) {
            return 5 * s.length();
        }
    }
}
