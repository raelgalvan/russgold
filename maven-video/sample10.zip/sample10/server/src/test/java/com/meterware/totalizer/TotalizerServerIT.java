package com.meterware.totalizer;
/********************************************************************************************************************
 * $Id$
 *
 * Copyright (c) 2008, Russell Gold
 *
 *******************************************************************************************************************/
import com.meterware.io.ClientMessageHandler;
import com.meterware.io.SocketServerAccess;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * @author <a href="mailto:russell.gold@oracle.com">Russell Gold</a>
 */
public class TotalizerServerIT {

    private static List<String> toteBoardCommands = new ArrayList<String>();
    private SocketServerAccess _serverAccess;
    private List<Object> replies = new ArrayList<Object>();

    @BeforeClass
    public static void setUpClass() throws Exception {
        toteBoardCommands.clear();
        new Thread( new TestToteBoard() ).start();
        Thread.sleep(100);
        new Thread() {
            public void run() {
                try {
                    Totalizer.createTotalizer(5001, 5002);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
        Thread.sleep(100);
    }
    
    @After
    public void tearDown() throws IOException {
        _serverAccess.disconnect();
    }

    @Test
    public void whenTerminalRequestsLoad_totalizerSendsCard() throws Exception {
        sendRequest(("LOAD " + new File("src/test/resources/card1.xml").getAbsolutePath()));
        
        Thread.sleep(1000);
        assertEquals( 1, replies.size() );
        assertTrue( replies.get(0) instanceof Card);
    }

    @Before
    public void contactTotalizer() throws IOException {
        _serverAccess = SocketServerAccess.connectToRemoteServer("localhost", 5001);
        _serverAccess.resume();
        _serverAccess.setHandler( new TerminalMessageHandler() );
    }


    @Test
    public void whenTerminalRequestsOdds_toteBoardUpdated() throws Exception {
        sendRequest( "DISPLAY Belmont 1" );

        Thread.sleep(1000);
        assertCommands("NEW 0",
                "DATA 0 0 Belmont", "DATA 0 1 1",
                "DATA 1 0 1", "DATA 1 1 Lucky Dan", "DATA 1 2 2-1",
                "DATA 2 0 2", "DATA 2 1 Charlie Horse", "DATA 2 2 10-1",
                "DATA 3 0 3", "DATA 3 1 Red Flag", "DATA 3 2 3-2",
                "DATA 4 0 4", "DATA 4 1 Holy Roller", "DATA 4 2 4-3",
                "END");
    }
    
    
    private void assertCommands( String... expected ) {
        assertEquals( expected.length, toteBoardCommands.size() );
        for (int i = 0; i < expected.length; i++) {
            if (!expected[i].equals(toteBoardCommands.get(i)))
                assertEquals( expected[i], withoutNBSP(toteBoardCommands.get(i)) );
        }
    }

    private String withoutNBSP(String s) {
        return s.replace((char) 0x0a0, ' ');
    }


    private void sendRequest( String request ) throws IOException {
        _serverAccess.sendRequest(request.getBytes());
    }



    class TerminalMessageHandler implements ClientMessageHandler {

        public boolean handleMessage( byte[] bytes ) {
            try {
                ByteArrayInputStream bais = new ByteArrayInputStream( bytes );
                ObjectInputStream ois = new ObjectInputStream( bais );
                Object result = ois.readObject();
                replies.add( result );
            } catch (Exception e) {
                replies.add(e);
            }
            return true;
        }
    }



    static class TestToteBoard implements Runnable {
        public void run() {
            try {
                ServerSocket serverSocket = new ServerSocket(5002);
                Socket socket = serverSocket.accept();
                InputStream inputStream = socket.getInputStream();
                byte[] buffer = new byte[2048];
                int size;
                while (-1 < (size = inputStream.read(buffer))) {
                    byte[] request = new byte[size];
                    System.arraycopy(buffer, 0, request, 0, size);
                    handleRequest(request);
                }
                socket.close();
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        protected void handleRequest(byte[] bytes) throws UnsupportedEncodingException {
            String request = new String(bytes, "UTF-8");
            while (request.length() > 0) {
                int i = request.indexOf('>');
                assert i > 0 : "no length indicator sent";
                String lengthString = request.substring(0, i);
                int length = Integer.parseInt(lengthString);
                toteBoardCommands.add(request.substring(i + 1, i + length + 1));
                request = request.substring(i + length + 1);
            }

        }

    }

}
