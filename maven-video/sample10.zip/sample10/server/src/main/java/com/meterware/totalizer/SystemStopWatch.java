package com.meterware.totalizer;

import java.util.Date;

class SystemStopWatch implements StopWatch {
    Date _lastUpdate = new Date();

    public void resetTimer() {
        _lastUpdate = new Date();
    }

    public long getElapsedTime() {
        return ((new Date().getTime() - _lastUpdate.getTime()) / 1000);
    }
}