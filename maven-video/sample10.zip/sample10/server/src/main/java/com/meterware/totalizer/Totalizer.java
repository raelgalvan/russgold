package com.meterware.totalizer;
/********************************************************************************************************************
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/
import com.meterware.totalizer.display.gui.ToteBoard;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class Totalizer {

    final TotalizerCore totalizerCore;

    public static void main( String args[] ) {
        try {
            createTotalizer( 5001, 5002 );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createTotalizer(int port, int toteBoardPort) throws IOException {
        Totalizer totalizer = new Totalizer(connectToToteBoard(toteBoardPort));
        ServerSocket serverSocket = new ServerSocket(port);
        while (true) {
            Socket socket = serverSocket.accept();
            new Thread( new TerminalHandler( totalizer, socket ) ).start();
        }
        // serverSocket.close();  should close when all terminals disconnect
    }

    static ToteBoardAccessImpl connectToToteBoard(int toteBoardPort) throws IOException {
        try {
            return new ToteBoardAccessImpl(toteBoardPort);
        } catch (IOException e) {
            ToteBoard.main();
            return new ToteBoardAccessImpl(toteBoardPort);
        }
    }


    Totalizer(ToteBoardAccess toteBoardAccess) throws IOException {
        totalizerCore = new TotalizerCore(new SystemStopWatch(), toteBoardAccess);
    }


    void handleRequest(byte[] requestBytes, OutputStream outputStream) throws IOException {
        totalizerCore.handleRequest(requestBytes, outputStream);
    }


    static class TerminalHandler implements Runnable {

        private Socket socket;
        private Totalizer totalizer;

        public TerminalHandler(Totalizer totalizer, Socket socket) {
            this.totalizer = totalizer;
            this.socket = socket;
        }

        public void run() {
            try {
                InputStream inputStream = socket.getInputStream();
                byte[] buffer = new byte[2048];
                int size;
                while (-1 < (size = inputStream.read(buffer))) {
                    byte[] request = new byte[size];
                    System.arraycopy(buffer, 0, request, 0, size);
                    totalizer.handleRequest(request, socket.getOutputStream());
                }
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
