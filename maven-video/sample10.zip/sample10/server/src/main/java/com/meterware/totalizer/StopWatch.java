package com.meterware.totalizer;

public interface StopWatch {
    void resetTimer();

    long getElapsedTime();
}
