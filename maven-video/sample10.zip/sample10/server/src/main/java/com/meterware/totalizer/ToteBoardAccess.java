package com.meterware.totalizer;

import java.io.IOException;

public interface ToteBoardAccess {
    void newFrame(int format) throws IOException;

    void sendData(int row, int column, Object value) throws IOException;

    void endFrame() throws IOException;
}
