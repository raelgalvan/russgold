package com.meterware.totalizer;
/********************************************************************************************************************
 *
 * Copyright (c) 2004, Russell Gold
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************/

import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;

/**
 *
 * @author <a href="mailto:russgold@com.meterware.com">Russell Gold</a>
 **/
public class Track {

    private static Hashtable<String,Track> tracks = new Hashtable<String,Track>();

    private String name;
    private Hashtable<Date,Card> cards = new Hashtable<Date,Card>();
    private Hashtable<String,BettingPool> pools = new Hashtable<String,BettingPool>();
    private Card currentCard;
    private int currentRace;


    public static Card loadCard( String fileName ) throws IOException {
        Card card = Card.load(fileName);
        defineTrack(card);
        return card;
    }

    public static void defineTrack(Card card) {
        Track track = getTrack( card.getTrack() );
        track.setCard( card.getDate(), card );
    }


    public static Track getTrack( String name ) {
        Track track = tracks.get( name.toLowerCase() );
        if (track == null) {
            track = new Track( name );
            defineTrack( track );
        }
        return track;
    }


    public String getName() {
        return name;
    }


    public Card getCard( Date date ) {
        return cards.get( date );
    }


    public Card getCurrentCard() {
        return currentCard;
    }


    public BettingPool getPool( Card card, String poolId ) {
        BettingPool pool = pools.get( poolId );
        if (pool == null) {
            pool = BettingPool.create( poolId );
            pools.put(poolId, pool);
        }
        return pool;
    }


    private void setCard( Date date, Card card ) {
        cards.put(date, card);
        currentCard = card;
    }


    static void defineTrack( Track track ) {
        tracks.put(track.getName().toLowerCase(), track);
        tracks.put("any", track);
    }


    private Track( String name ) {
        this.name = name;
    }


    public static void clear() {
        tracks.clear();
    }


    public double getPayoutPortion() {
        return 0.90;
    }


    public void setCurrentRace( int raceNum ) {
        currentRace = raceNum;
    }


    public int currentRace() {
        return currentRace;
    }

    /**
     * Returns true if there are enough bets to display odds based on the wagering.
     */
    public boolean hasEnoughBets() {
        return haveWinBetsForMajorityOfHorses();
    }

    private boolean haveWinBetsForMajorityOfHorses() {
        return numHorsesWithWinBets() * 2 > numHorsesInCurrentRace();
    }

    private int numHorsesWithWinBets() {
        BettingPool pool = getPool(currentCard, "WIN-"+ currentRace);
        int numHorsesBetOn = 0;
        for (int i = 0; i < numHorsesInCurrentRace(); i++) {
            if (pool.getBet( i ) > 0) numHorsesBetOn++;
        }
        return numHorsesBetOn;
    }

    private int numHorsesInCurrentRace() {
        return currentCard.getRace(currentRace).getNumHorses();
    }

}
