package com.meterware.io;
/********************************************************************************************************************
 *
 * Copyright (c) 2004, 2013, Russell Gold
 *
 *******************************************************************************************************************/
import java.util.Iterator;
import java.nio.ByteBuffer;

/**
 *
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 **/
public class MessageIterator implements Iterator<byte[]> {

    private ByteBuffer buffer;

    public MessageIterator(byte[] bytes) {
        buffer = ByteBuffer.wrap( bytes );
    }


    public boolean hasNext() {
        return buffer.hasRemaining();
    }


    public byte[] next() {
        int length = buffer.getInt();
        byte[] message = new byte[length];
        buffer.get(message);
        return message;
    }


    public void remove() {
        throw new java.lang.UnsupportedOperationException();
    }

}
