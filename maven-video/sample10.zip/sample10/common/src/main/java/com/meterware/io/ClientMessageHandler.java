package com.meterware.io;
/********************************************************************************************************************
 *
 * Copyright (c) 2004,2013 Russell Gold
 *
 *******************************************************************************************************************/

/**
 * An interface which a client of @{link SocketServerAccess} uses to handle replies from a server.
 *
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 **/
public interface ClientMessageHandler {

    /**
     * Handles the specified message content. Returns false if the handling thread should exit.
     */
    boolean handleMessage( byte[] bytes );

}
