package com.meterware.totalizer;
/********************************************************************************************************************
 *
 * Copyright (c) 2004-2005, Russell Gold
 *
 *******************************************************************************************************************/
import java.util.ArrayList;

/**
 * A pool of all bets placed for horses to achieve a particular result. Payouts will be divided among the winners
 * after deducting the track take.
 *
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 **/
public class BettingPool {

    public static int WIN   = 0;
    public static int PLACE = 1;
    public static int SHOW  = 2;

    private ArrayList<Double> bets = new ArrayList<Double>();
    private int raceNum;
    private int poolType;

    /**
     * Adds a bet on a horse into this pool.
     * @param horseNum
     * @param amount
     */
    public void addBet( int horseNum, double amount ) {
        bets.set(horseNum, amount + getBet(horseNum));
    }


    public double getBet( int horseNum ) {
        while (bets.size() <= horseNum) bets.add( 0.0 );
        return bets.get(horseNum);
    }


    public double getTotalBets() {
        double totalBets = 0;
        for (int i = 0; i < bets.size(); i++) {
            totalBets += getBet(i);
        }
        return totalBets;
    }


    public boolean isWinPool() {
        return poolType == WIN;
    }


    public static BettingPool create( String poolId ) {
        int raceNum = Integer.parseInt( poolId.substring( poolId.indexOf( '-' ) +1 ) );
        String type = poolId.substring( 0, poolId.indexOf( '-' ) );
        if (type.equalsIgnoreCase( "win" ) ) {
            return new BettingPool( WIN, raceNum );
        } else if (type.equalsIgnoreCase( "place" ) ) {
            return new BettingPool( PLACE, raceNum );
        } else if (type.equalsIgnoreCase( "show" ) ) {
            return new BettingPool( SHOW, raceNum );
        } else {
            throw new RuntimeException( "No such pool type: " + poolId );
        }
    }


    private BettingPool( int poolType, int raceNum ) {
        this.poolType = poolType;
        this.raceNum = raceNum;
    }


    public int getRace() {
        return raceNum;
    }
}
