package com.meterware.io;
/********************************************************************************************************************
 *
 * Copyright (c) 2004, 2013, Russell Gold
 *
 *******************************************************************************************************************/
import java.io.IOException;

/**
 * An interface for clients to invoke a server.
 *
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public interface ServerAccess {

    /**
     * Disconnects from the server.
     * @throws IOException if the disconnect fails.
     */
    void disconnect() throws IOException;

    /**
     * Pauses processing of server messages. Typically used when invoked from an applet whose page is no longer current.
     */
    void pause();

    /**
     * Restarts response processing after a pause or when the client is initially ready to handle server messages.
     */
    void resume();

    /**
     * Specifies the processing for messages from the server.
     * @param handler the client-specified handler.
     */
    void setHandler(ClientMessageHandler handler);

    /**
     * Sends a request to the server.
     * @param requestBody the message to send
     * @throws IOException on any error
     */
    void sendRequest(byte[] requestBody) throws IOException;
}
