package com.meterware.totalizer.control;

/**
 * Created with IntelliJ IDEA.
 * User: russgold
 * Date: 4/28/13
 * Time: 1:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ControlView {
    void setListener(ControlViewListener listener);

    void setPossibleShowers(String[] horses);

    void setPossiblePlacers(String[] horses);

    void setPossibleWinners(String[] horses);

    void setOfferedRaces(int[] openRaces);

    void setTrackName(String track);
}
