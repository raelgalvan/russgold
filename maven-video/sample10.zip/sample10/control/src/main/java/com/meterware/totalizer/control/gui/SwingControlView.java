package com.meterware.totalizer.control.gui;

import com.meterware.totalizer.control.ControlView;
import com.meterware.totalizer.control.ControlViewListener;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class SwingControlView implements ControlView {
    private JFileChooser fileChooser;
    private JLabel trackLabel;
    private JButton submitButton;
    private JComboBox raceComboBox;
    private JComboBox winComboBox;
    private JComboBox placeComboBox;
    private JComboBox showComboBox;
    private JButton displayButton;

    private ControlViewListener listener;

    public SwingControlView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(BorderLayout.NORTH, createLoadPanel());
        panel.add(BorderLayout.CENTER, createControlPanel());
        Frame frame = new Frame();
        frame.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e ) {
                System.exit( 0 );
            }
        } );
        frame.setLayout( new GridLayout() );
        frame.add(panel);
        frame.setSize(400, 200);
        frame.setVisible(true);
    }

    public void setListener(ControlViewListener listener) {
        this.listener = listener;
    }

    public void setPossibleShowers(String[] horses) {
        showComboBox.setEnabled(true);
        showComboBox.removeAllItems();
        showComboBox.addItem("-- select show --");
        for (int i = 0; i < horses.length; i++) {
            showComboBox.addItem(horses[i]);
        }
        submitButton.setEnabled(false);
    }

    private void disableShow() {
        showComboBox.setEnabled(false);
        showComboBox.removeAllItems();
    }

    private void disablePlace() {
        placeComboBox.setEnabled(false);
        placeComboBox.removeAllItems();

        disableShow();
    }

    public void setPossiblePlacers(String[] horses) {
        placeComboBox.setEnabled(true);
        placeComboBox.removeAllItems();
        placeComboBox.addItem("-- select place --");
        for (int i = 0; i < horses.length; i++) {
            placeComboBox.addItem(horses[i]);
        }

        disableShow();
    }

    public void setPossibleWinners(String[] horses) {
        winComboBox.setEnabled(true);
        winComboBox.removeAllItems();
        winComboBox.addItem("-- select winner --");
        for (int i = 0; i < horses.length; i++) {
            winComboBox.addItem(horses[i]);
        }

        disablePlace();
        displayButton.setEnabled(true);
    }

    public void setOfferedRaces(int[] openRaces) {
        raceComboBox.setEnabled(true);
        raceComboBox.removeAllItems();
        for (int i = 0; i < openRaces.length; i++) {
            int openRace = openRaces[i];
            raceComboBox.addItem(new Integer(openRace));
        }
    }

    public void setTrackName(String track) {
        trackLabel.setText("Welcome to " + track);
    }

    private Component createHorseSelectionPanel() {
        JPanel contents = new JPanel( new GridLayout( 5, 2 ) );
        contents.add( new JLabel( "Race: ", JLabel.RIGHT ) );
        contents.add( raceComboBox = new JComboBox() );
        contents.add( new JLabel( "Win:", JLabel.RIGHT ) );
        contents.add( winComboBox = new JComboBox() );
        contents.add( new JLabel( "Place:", JLabel.RIGHT ) );
        contents.add( placeComboBox = new JComboBox() );
        contents.add( new JLabel( "Show:", JLabel.RIGHT ) );
        contents.add( showComboBox = new JComboBox() );
        contents.add( displayButton = new JButton( "Display Odds" ) );
        contents.add( submitButton = new JButton( "Post Results") );

        raceComboBox.setEnabled(false);
        winComboBox.setEnabled(false);
        placeComboBox.setEnabled(false);
        showComboBox.setEnabled(false);
        displayButton.setEnabled(false);
        submitButton.setEnabled(false);

        raceComboBox.addItemListener(new NumericItemListener() {
            void reportChange(int i) {
                listener.selectRace(i);
            }
        });

        winComboBox.addItemListener(new NumericItemListener() {
            void reportChange(int i) {
                listener.selectWinner(i);
            }
        });

        placeComboBox.addItemListener(new NumericItemListener() {
            void reportChange(int i) {
                listener.selectPlace(i);
            }
        });

        showComboBox.addItemListener(new NumericItemListener() {
            void reportChange(int i) {
                listener.selectShow(i);
                submitButton.setEnabled(true);
            }
        });

        displayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listener.displayOdds();
            }
        });

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listener.displayResults();
            }
        });
        return contents;
    }

    private Component createControlPanel() {
        JPanel panel = new JPanel( new BorderLayout() );
        panel.add( BorderLayout.NORTH, trackLabel = new JLabel( "Choose a track", JLabel.CENTER ) );
        panel.add( BorderLayout.CENTER, createHorseSelectionPanel() );
        return panel;
    }

    private Component createLoadPanel() {
        final JPanel panel = new JPanel();
        JButton button = new JButton( "Load Card..." );
        panel.add( button );
        fileChooser = new JFileChooser( new File("") );
        fileChooser.setFileFilter(new FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().endsWith(".xml");
            }

            public String getDescription() {
                return "XML files";
            }
        });
        button.addActionListener( new ActionListener() {
            public void actionPerformed( ActionEvent e ) {
                if (JFileChooser.APPROVE_OPTION == fileChooser.showOpenDialog( panel ) ) {
                    File file = fileChooser.getSelectedFile();
                    listener.loadCard(file);
                }
            }
        } );
        return panel;
    }

    abstract static class NumericItemListener implements ItemListener {

        public void itemStateChanged( ItemEvent e ) {
            if (e.getStateChange() == ItemEvent.DESELECTED) return;
            String valueString = e.getItem().toString();
            if (!Character.isDigit( valueString.charAt( 0 ) )) return;
            if (valueString.indexOf( ' ' ) > 0) valueString = valueString.substring( 0, valueString.indexOf( ' ' ) );
            reportChange( Integer.parseInt( valueString ) );
        }

        abstract void reportChange( int i );
    }
}
