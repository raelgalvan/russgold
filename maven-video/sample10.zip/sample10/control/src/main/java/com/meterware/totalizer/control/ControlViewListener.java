package com.meterware.totalizer.control;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: russgold
 * Date: 4/28/13
 * Time: 1:31 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ControlViewListener {
    void selectRace(int raceNum);

    void selectWinner(int horseNum);

    void selectPlace(int horseNum);

    void displayOdds();

    void displayResults();

    void loadCard(File file);

    void selectShow(int horseNum);
}
