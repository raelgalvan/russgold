package com.meterware.totalizer.control.gui;

import com.meterware.io.ServerAccess;
import com.meterware.io.SocketServerAccess;
import com.meterware.totalizer.control.ControlTerminal;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: russgold
 * Date: 4/28/13
 * Time: 1:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class ControlTerminalMain {
    public static void main( String[] args ) {
        try {
            if (args.length == 0) {
                launchTerminal( "localhost", 5001 );
            } else if (args.length == 2) {
                launchTerminal( args[0], Integer.parseInt( args[1] ) );
            } else {
                System.out.println( "Usage: java -jar ControlTerminal <host-name> <port>" );
            }

        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private static void launchTerminal( String hostName, int port ) throws IOException {
        ServerAccess serverAccess = SocketServerAccess.connectToRemoteServer(hostName, port);
        new ControlTerminal( serverAccess, new SwingControlView() );
    }
}
