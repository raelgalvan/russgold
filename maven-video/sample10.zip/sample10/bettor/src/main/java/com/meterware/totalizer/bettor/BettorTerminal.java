package com.meterware.totalizer.bettor;
/********************************************************************************************************************
 *
 * Copyright (c) 2005,2013 Russell Gold
 *
 *******************************************************************************************************************/

import com.meterware.io.ClientMessageHandler;
import com.meterware.io.ServerAccess;
import com.meterware.totalizer.Card;
import com.meterware.totalizer.Race;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class BettorTerminal implements BettorListener {

    private ServerAccess serverAccess;
    private Card card;
    private int raceNum;
    private BettorView view;


    public BettorTerminal(String trackName, BettorView view, ServerAccess serverAccess) {
        this.view = view;
        this.view.setListener(this);

        this.serverAccess = serverAccess;
        this.serverAccess.resume();
        serverAccess.setHandler(new TerminalMessageHandler());
        sendRequest(("DOWNLOAD " + trackName));
    }


    public void selectRace(int raceNum) {
        this.raceNum = raceNum;
        view.setOfferedHorses(getHorseStrings(card.getRace(raceNum)));
        view.setOfferedPools(new String[]{"Win", "Place", "Show"});
    }

    private String[] getHorseStrings(Race race) {
        ArrayList<String> horses = new ArrayList<String>();
        for (int i = 0; i < race.getNumHorses(); i++) {
            horses.add((i + 1) + " " + race.getHorse(i + 1).getName());
        }
        return horses.toArray(new String[horses.size()]);
    }


    public void submitBet(int horseNum, String poolType, double betAmount) {
        sendRequest("BET " + card.getTrack() + ' ' + poolType.toUpperCase() + '-' + raceNum + ' ' + horseNum + ' ' + betAmount);
    }


    private void sendRequest(String request) {
        try {
            serverAccess.sendRequest(request.getBytes("UTF8"));
        } catch (IOException e) {
            reportException(e);
        }
    }


    private void reportException(Exception e) {
        e.printStackTrace();
    }


    private void setCard(Card card) {
        this.card = card;
        view.setTrackName(card.getTrack());
        int[] openRaces = new int[card.getNumRaces()];
        for (int i = 0; i < openRaces.length; i++) {
            openRaces[i] = (i + 1);
        }
        view.setOfferedRaces(openRaces);
        selectRace(openRaces[0]);
    }


    class TerminalMessageHandler implements ClientMessageHandler {

        public boolean handleMessage(byte[] bytes) {
            try {
                ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                ObjectInputStream ois = new ObjectInputStream(bais);
                Object result = ois.readObject();
                if (result instanceof Card) {
                    setCard((Card) result);
                } else {
                    reportException(new RuntimeException("Received " + result + " instead of a Card"));
                }
            } catch (IOException e) {
                reportException(e);
            } catch (ClassNotFoundException e) {
                reportException(e);
            }
            return true;
        }
    }
}
