package com.meterware.totalizer.bettor.gui;
/********************************************************************************************************************
 *
 * Copyright (c) 2005, Russell Gold
 *
 *******************************************************************************************************************/

import com.meterware.totalizer.bettor.BettorListener;
import com.meterware.totalizer.bettor.BettorView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A Swing implementation of a bettor view
 */
public class SwingBettorView implements BettorView {
    private JLabel tracklabel;
    private JComboBox raceComboBox;
    private JComboBox horseComboBox;
    private JComboBox poolComboBox;
    private JTextField betAmountField;
    private BettorListener listener;

    public SwingBettorView() {
        JPanel panel = new JPanel(new BorderLayout());
        layoutControls(panel);

        Frame frame = new Frame();
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        frame.setLayout(new GridLayout());
        frame.add(panel);
        frame.setSize(400, 150);
        frame.setVisible(true);
    }

    @Override
    public void setListener(BettorListener listener) {
        this.listener = listener;
    }

    @Override
    public void setTrackName(String trackName) {
        tracklabel.setText("Welcome to " + trackName);
    }

    @Override
    public void setOfferedRaces(int[] openRaces) {
        raceComboBox.removeAllItems();
        for (int i = 0; i < openRaces.length; i++) {
            int openRace = openRaces[i];
            raceComboBox.addItem(new Integer(openRace));
        }
    }

    @Override
    public void setOfferedHorses(String[] strings) {
        horseComboBox.removeAllItems();
        for (int i = 0; i < strings.length; i++) {
            horseComboBox.addItem(strings[i]);
        }
    }

    @Override
    public void setOfferedPools(String[] strings) {
        poolComboBox.removeAllItems();
        for (int i = 0; i < strings.length; i++) {
            poolComboBox.addItem(strings[i]);
        }
    }

    void layoutControls(JPanel view) {
        view.add(BorderLayout.NORTH, tracklabel = new JLabel("No track specified", JLabel.CENTER));
        JPanel contents = new JPanel(new GridLayout(4, 2));
        view.add(BorderLayout.CENTER, contents);
        contents.add(new JLabel("Race:", JLabel.RIGHT));
        contents.add(raceComboBox = new JComboBox());
        contents.add(new JLabel("Horse:", JLabel.RIGHT));
        contents.add(horseComboBox = new JComboBox());
        contents.add(new JLabel("Pool:", JLabel.RIGHT));
        contents.add(poolComboBox = new JComboBox());
        contents.add(new JLabel("Bet amount:", JLabel.RIGHT));
        contents.add(betAmountField = new JTextField("0"));
        JButton submitButton = new JButton("Submit Bet");
        view.add(BorderLayout.SOUTH, submitButton);

        raceComboBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.DESELECTED) return;
                listener.selectRace(Integer.parseInt(e.getItem().toString()));
            }
        });

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listener.submitBet(getSelectedHorse(), getSelectedPool(), getBetAmount());
            }
        });
    }

    private String getSelectedPool() {
        return poolComboBox.getSelectedItem().toString();
    }

    private int getSelectedHorse() {
        return horseComboBox.getSelectedIndex() + 1;
    }

    private double getBetAmount() {
        return Double.parseDouble(betAmountField.getText());
    }

}
