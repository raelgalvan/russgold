package com.meterware.totalizer.bettor;

/**
 * Created with IntelliJ IDEA.
 * User: russgold
 * Date: 4/28/13
 * Time: 11:20 AM
 * To change this template use File | Settings | File Templates.
 */
public interface BettorView {
    void setListener(BettorListener listener);

    void setTrackName(String trackName);

    void setOfferedRaces(int[] openRaces);

    void setOfferedHorses(String[] strings);

    void setOfferedPools(String[] strings);
}
