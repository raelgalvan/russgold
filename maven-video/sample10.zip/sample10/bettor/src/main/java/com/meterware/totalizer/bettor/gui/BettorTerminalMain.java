package com.meterware.totalizer.bettor.gui;

import com.meterware.io.SocketServerAccess;
import com.meterware.totalizer.bettor.BettorTerminal;

import java.io.IOException;

/**
 * @author <a href="mailto:russgold@gmail.com">Russell Gold</a>
 */
public class BettorTerminalMain {
    public static void main(String[] args) {
        try {
            if (args.length == 0) {
                launchTerminal("localhost", 5001, "Belmont");
            } else if (args.length == 3) {
                launchTerminal(args[0], Integer.parseInt(args[1]), args[2]);
            } else {
                System.out.println("Usage: java -jar BettorTerminal <host-name> <port> <track>");
            }

        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private static void launchTerminal(String hostName, int port, String track) throws IOException {
        new BettorTerminal(track, new SwingBettorView(), SocketServerAccess.connectToRemoteServer(hostName, port));
    }
}
