package com.meterware.codebreaker;

import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.meterware.codebreaker.Color.*;
import static org.junit.Assert.assertEquals;

public class CodebreakerTest {

    private Codebreaker codebreaker;
    private boolean mayUseEmpty = true;
    private int numPegs;

    @Test
    public void order2GuesserInitialized_hasSquareOfNumColors() {
        setNumPegs(2);
        assertEquals(Codebreaker.NUM_COLORS * Codebreaker.NUM_COLORS, numCombinationsLeft());
    }

    private int numCombinationsLeft() {
        return getCodebreaker().numCombinationsLeft();
    }

    @Test
    public void disablingEmpty_reducesNumOptions() {
        setNumPegs(2);
        setMayUseEmpty(false);
        assertEquals((Codebreaker.NUM_COLORS-1) * (Codebreaker.NUM_COLORS-1), numCombinationsLeft());
    }

    @Test
    public void singleMatch_reducesGuessesToDoubleNumColors() {
        setNumPegs(2);
        addResult(1, 0, red, white);
        assertEquals(2 * Codebreaker.NUM_COLORS - 2, numCombinationsLeft());
    }

    @Test
    public void initialGuess_hasNoDuplicateColors() {
        setNumPegs(5);
        assertEquals(getNumPegs(), getNumUniqueColors(getCodebreaker().getNextGuess()));
    }

    private int getNumUniqueColors(Color[] guess) {
        List<Color> list = Arrays.asList(guess);
        return new HashSet<Color>(list).size();
    }

    @Test
    public void sequenceReducesGuessesToOne() {
        setNumPegs(5);
        setMayUseEmpty(false);
        addResult(1, 2, white, purple, orange, pink, red);
        addResult(1, 3, white, orange, purple, green, blue);
        addResult(2, 2, white, pink, green, blue, purple);
        addResult(2, 1, white, pink, blue, orange, green);

        assertEquals(1, numCombinationsLeft());
    }

    private void addResult(int numMatches, int numMismatches, Color... guess) {
        getCodebreaker().addResult(guess, new Result(numMatches, numMismatches));
    }

    private Codebreaker getCodebreaker() {
        if (codebreaker == null)
            codebreaker = new Codebreaker(numPegs, mayUseEmpty);
        return codebreaker;
    }

    private void setMayUseEmpty(boolean mayUseEmpty) {
        this.mayUseEmpty = mayUseEmpty;
    }

    private int getNumPegs() {
        return numPegs;
    }

    private void setNumPegs(int numPegs) {
        this.numPegs = numPegs;
    }
}
