package com.meterware.codebreaker;

import org.junit.Test;

import static com.meterware.codebreaker.Color.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class MatcherTest {

    private Color[] secret;

    @Test
    public void forCompleteMatch_returnAllMatches() {
        defineSecret(red, white, blue, green, purple);
        assertEquals(new Result(5, 0), guess(red, white, blue, green, purple));
    }

    private Result guess(Color... colors) {
        return Matcher.guess(secret, colors);
    }

    private void defineSecret(Color... colors) {
        secret = colors;
    }

    @Test
    public void forNoMatches_returnEmpty() {
        defineSecret(red, white, blue, green, purple);
        assertEquals(new Result(0, 0), guess(orange, yellow, pink, empty, pink));
    }

    @Test
    public void forCompleteMismatch_returnAllMismatches() {
        defineSecret(red, white, blue, green, purple);
        assertEquals(new Result(0, 5), guess(white, blue, green, purple, red));
    }

    @Test
    public void forCombinationMatchMismatch1_returnTrueAndFalse() {
        defineSecret(red, white, blue, green, purple);
        assertEquals(new Result(1, 2), guess(white, white, green, blue, orange));
    }

    @Test
    public void forCombinationMatchMismatch2_returnTrueAndFalse() {
        defineSecret(purple, white, green, purple, green);
        assertEquals(new Result(1, 0), guess(white, white, yellow, red, orange));
        assertEquals(new Result(0, 2), guess(green, green, pink, pink, orange));
        assertEquals(new Result(2, 1), guess(purple, purple, green, red, pink));
        assertEquals(new Result(1, 0), guess(pink, blue, green, red, red));
    }

    @Test
    public void forCombinationMatchMismatch4_returnTrueAndFalse() {
        defineSecret(pink, white, green, orange, pink);
        assertEquals(new Result(1, 1), guess(pink, red, yellow, white, white));
    }

    @Test
    public void forCombinationMatchMismatch3_returnTrueAndFalse() {
        defineSecret(pink, red, yellow,  white, white);
        assertEquals(new Result(1, 1), guess(pink, white, green, orange, pink));
        assertEquals(new Result(2, 0), guess(orange, red, orange, orange, white));
        assertEquals(new Result(0, 1), guess(purple, yellow, orange, orange, green));
        assertEquals(new Result(2, 0), guess(orange, white, white, white, white));
        assertEquals(new Result(1, 1), guess(orange, white, blue, blue, white));
    }

}
