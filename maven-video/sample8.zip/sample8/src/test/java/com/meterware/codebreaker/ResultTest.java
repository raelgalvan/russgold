package com.meterware.codebreaker;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the Result class.
 */
public class ResultTest {

    @Test
    public void resultDoesntMatchNull() {
        assertFalse(matchesOneAndOneResult(null));
    }

    @Test
    public void resultDoesntMatchNonResult() {
        assertFalse(matchesOneAndOneResult("not a result"));
    }

    @Test
    public void resultDoesntMatchDifferentResult() {
        assertFalse(matchesOneAndOneResult(new Result(0, 2)));
    }

    private boolean matchesOneAndOneResult(Object o) {
        return new Result(1, 1).equals(o);
    }

    @Test
    public void resultMatchesSameResult() {
        Result result = new Result(2, 0);
        assertTrue(result.equals(result));
    }

    @Test
    public void resultMatchesIdenticalResult() {
        assertEquals(new Result(2, 1), new Result(2, 1));
    }

}
