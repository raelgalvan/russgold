package com.meterware.codebreaker;

import java.util.ArrayList;
import java.util.List;

class Matcher {
    private Color[] actuals;
    private Color[] guesses;

    private final List<Color> candidates = new ArrayList<Color>();
    private final List<Color> unmatched = new ArrayList<Color>();
    private int numMatches = 0;
    private int numMismatches = 0;

    static Result guess(Color[] actuals, Color[] guesses) {
        return new Matcher(actuals, guesses).invoke();
    }


    Matcher(Color[] actuals, Color[] guesses) {
        this.actuals = actuals;
        this.guesses = guesses;
    }


    private int getNumMismatches() {
        int numMismatches = 0;
        for (Color color : candidates) {
            if (unmatched.contains(color)) {
                unmatched.remove(color);
                numMismatches++;
            }
        }
        return numMismatches;
    }

    Result invoke() {
        for (int i = 0; i < guesses.length; i++)
            checkMatch(i);
        addMismatches(getNumMismatches());
        return new Result(numMatches, numMismatches);
    }

    private void checkMatch(int i) {
        if (guesses[i] == actuals[i])
            addMatch();
        else
            addPossibleMismatch(i);
    }

    private void addPossibleMismatch(int i) {
        candidates.add(guesses[i]);
        unmatched.add(actuals[i]);
    }

    private void addMatch() {
        numMatches++;
    }

    private void addMismatches(int size) {
        for (int i = 0; i < size; i++)
            numMismatches++;
    }

}
