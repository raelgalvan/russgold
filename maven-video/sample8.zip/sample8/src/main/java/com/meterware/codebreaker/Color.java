package com.meterware.codebreaker;

enum Color {yellow, blue, green, red, pink, orange, purple, white, empty}
