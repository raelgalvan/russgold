/**
 * This package contains the logic for the CodeBreaker functionality.
 */
package com.meterware.codebreaker;