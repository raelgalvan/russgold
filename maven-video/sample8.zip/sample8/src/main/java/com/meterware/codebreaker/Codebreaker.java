package com.meterware.codebreaker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

/**
 * This class is a basic solver for the
 * <a href="http://en.wikipedia.org/wiki/Mastermind_(board_game)">Mastermind game.</a> For each turn, a call to
 * {@link #getNextGuess} will return a guess to be tried against the actual solution. The solver is then updated
 * with a call to {@link #addResult addResult()}. The game is solved when the guess matches the solution.
 */
public class Codebreaker {

    final static Set<Color> allColors = EnumSet.allOf(Color.class);
    final static int NUM_COLORS = allColors.size();

    private List<Color[]> remainingCombinations = new ArrayList<Color[]>();
    private boolean useEmpty;

    private static Comparator<Color[]> GUESS_COMPARATOR =
            new Comparator<Color[]>() {
                public int compare(Color[] left, Color[] right) {
                    return compareInt(numUniqueColors(left), numUniqueColors(right));
                }
            };

    private static int compareInt(int left, int right) {
        return left < right ? -1 : left == right ? 0 : +1;
    }

    private static int numUniqueColors(Color[] colors) {
        return new HashSet<Color>( Arrays.asList(colors)).size();
    }

    /**
     * Creates an object which can solve a mastermind game.
     * @param order the number of slots in a challenge
     * @param useEmpty if true, a slot may be empty
     */
    public Codebreaker(int order, boolean useEmpty) {
        this.useEmpty = useEmpty;
        createPermutations(new Color[0], order);
    }

    private void createPermutations(Color[] prefix, int numToAdd) {
        if (numToAdd == 0) {
            remainingCombinations.add(prefix.clone());
        } else {
            Color[] newPrefix = new Color[prefix.length+1];
            System.arraycopy(prefix, 0, newPrefix, 0, prefix.length);
            for (Color color : allColors) {
                if (color == Color.empty && !useEmpty) continue;
                newPrefix[prefix.length] = color;
                createPermutations(newPrefix, numToAdd-1);
            }
        }

    }

    /**
     * Returns the next guess as an array of colors.
     * @return an array to use as the next guess
     */
    public Color[] getNextGuess() {
        Collections.sort(remainingCombinations, GUESS_COMPARATOR);
        return remainingCombinations.get(remainingCombinations.size()-1);
    }

    /**
     * Returns the number of possible combinations which could match the solution.
     * @return a count of all of the combinations which have not yet been eliminated
     */
    public int numCombinationsLeft() {
        return remainingCombinations.size();
    }

    /**
     * Adds the result of the specified guess and eliminates any now-impossible guesses.
     * @param guess the guess, as an array of colors
     * @param result the result of trying the guess on the puzzle
     */
    public void addResult(Color[] guess, Result result) {
        for (ListIterator<Color[]> each = remainingCombinations.listIterator(); each.hasNext();) {
            Color[] item = each.next();
            Result proposedResult = Matcher.guess(guess, item);
            if (!proposedResult.equals(result))
                each.remove();
        }
    }
}
