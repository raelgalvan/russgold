package com.meterware.codebreaker;

class Result {
    private int numMatches;
    private int numMismatches;

    Result(int numMatches, int numMismatches) {
        this.numMatches = numMatches;
        this.numMismatches = numMismatches;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Result other = (Result) o;

        return numMatches == other.numMatches && numMismatches == other.numMismatches;
    }
}
