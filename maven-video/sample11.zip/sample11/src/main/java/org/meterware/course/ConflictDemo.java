package org.meterware.course;

import javax.persistence.LockModeType;
import javax.persistence.Query;

public class ConflictDemo {

    public void setLock(Query query, LockModeType lockModeType) {
        query.setLockMode(lockModeType);
    }
}
